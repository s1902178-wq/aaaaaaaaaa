// Copyright © 2020 The CefSharp Authors. All rights reserved.
//
// Use of this source code is governed by a BSD-style license that can be found in the LICENSE file.

using System.Diagnostics;
using System.Threading.Tasks;
using CefSharp.Event;
using CefSharp.Example;
using CefSharp.Example.JavascriptBinding;
using CefSharp.Internals;
using CefSharp.OffScreen;
using Xunit;
using Xunit.Abstractions;

namespace CefSharp.Test.JavascriptBinding
{
    [Collection(CefSharpFixtureCollection.Key)]
    public class JavascriptBindingTests : BrowserTests
    {
        private readonly ITestOutputHelper output;
        private readonly CefSharpFixture fixture;

        public JavascriptBindingTests(ITestOutputHelper output, CefSharpFixture fixture)
        {
            this.fixture = fixture;
            this.output = output;
        }

        [Fact]
        public async Task ShouldWork()
        {
            AssertInitialLoadComplete();

            const string script = @"
                (async function()
                {
                    await CefSharp.BindObjectAsync('bound');
                    return await bound.echo('Welcome to CefSharp!');
                })();";

            var boundObj = new BindingTestObject();

#if NETCOREAPP
            Browser.JavascriptObjectRepository.Register("bound", boundObj);
#else
            Browser.JavascriptObjectRepository.Register("bound", boundObj, true);
#endif

            var result = await Browser.EvaluateScriptAsync<string>(script);

            Assert.Equal(1, boundObj.EchoMethodCallCount);
            Assert.Equal("Welcome to CefSharp!", result);
        }

        [Fact]
        //Issue https://github.com/cefsharp/CefSharp/issues/3470
        //Verify workaround passes
        public async Task ShouldRaiseResolveObjectEvent()
        {
            AssertInitialLoadComplete();

            var evt = await Assert.RaisesAsync<JavascriptBindingEventArgs>(
                x => Browser.JavascriptObjectRepository.ResolveObject += x,
                y => Browser.JavascriptObjectRepository.ResolveObject -= y,
                () => Browser.EvaluateScriptAsync("CefSharp.BindObjectAsync();"));

            Assert.NotNull(evt);

            Assert.Equal(JavascriptObjectRepository.AllObjects, evt.Arguments.ObjectName);
        }

        [Fact]
        public async Task ShouldWorkWhenUsingCustomGlobalObjectName()
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiGlobalObjectName = "bindingApiObject";

                //To modify the settings we need to defer browser creation slightly
                browser.CreateBrowser();

                await browser.WaitForInitialLoadAsync();

                var result = await browser.EvaluateScriptAsync("bindingApiObject.isObjectCached('doesntexist') === false");

                Assert.True(result.Success, result.Message);
            }
        }

        [Fact]
        public async Task ShouldWorkWhenUsingCustomGlobalObjectNameInMultipleBrowsers()
        {
            using var browser1 = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false);
            using var browser2 = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false);
            using var browser3 = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false);

            browser1.JavascriptObjectRepository.Settings.JavascriptBindingApiGlobalObjectName = "bindingApiObject1";
            browser2.JavascriptObjectRepository.Settings.JavascriptBindingApiGlobalObjectName = "bindingApiObject2";

            //To modify the settings we need to defer browser creation slightly
            browser1.CreateBrowser();
            browser2.CreateBrowser();
            browser3.CreateBrowser();

            await browser1.WaitForInitialLoadAsync();
            await browser2.WaitForInitialLoadAsync();
            await browser3.WaitForInitialLoadAsync();

            // Assert browser1
            {
                var result1 = await browser1.EvaluateScriptAsync("typeof window.bindingApiObject1 === 'undefined'");
                var result2 = await browser1.EvaluateScriptAsync("typeof window.bindingApiObject2 === 'undefined'");
                var result3 = await browser1.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");

                Assert.True(result1.Success, result1.Message);
                Assert.False((bool)result1.Result);

                Assert.True(result2.Success, result2.Message);
                Assert.True((bool)result2.Result);

                Assert.True(result3.Success, result3.Message);
                Assert.True((bool)result3.Result);
            }
            // Assert browser2
            {
                var result1 = await browser2.EvaluateScriptAsync("typeof window.bindingApiObject1 === 'undefined'");
                var result2 = await browser2.EvaluateScriptAsync("typeof window.bindingApiObject2 === 'undefined'");
                var result3 = await browser2.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");

                Assert.True(result1.Success, result1.Message);
                Assert.True((bool)result1.Result);

                Assert.True(result2.Success, result2.Message);
                Assert.False((bool)result2.Result);

                Assert.True(result3.Success, result3.Message);
                Assert.True((bool)result3.Result);
            }
            // Assert browser3
            {
                var result1 = await browser3.EvaluateScriptAsync("typeof window.bindingApiObject1 === 'undefined'");
                var result2 = await browser3.EvaluateScriptAsync("typeof window.bindingApiObject2 === 'undefined'");
                var result3 = await browser3.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");

                Assert.True(result1.Success, result1.Message);
                Assert.True((bool)result1.Result);

                Assert.True(result2.Success, result2.Message);
                Assert.True((bool)result2.Result);

                Assert.True(result3.Success, result3.Message);
                Assert.False((bool)result3.Result);
            }
        }

        [Theory]
        //We'll execute twice using the different cased (camelcase naming and standard)
        [InlineData("CefSharp.IsObjectCached('doesntexist')")]
        [InlineData("cefSharp.isObjectCached('doesntexist')")]
        public async Task ShouldFailWhenIsObjectCachedCalledWithInvalidObjectName(string script)
        {
            var loadResponse = await Browser.LoadUrlAsync(CefExample.BindingApiCustomObjectNameTestUrl);

            Assert.True(loadResponse.Success);

            var response = await Browser.EvaluateScriptAsync(script);

            Assert.True(response.Success, response.Message);
            Assert.False((bool)response.Result);
        }

        [Fact]
        public async Task ShouldDisableJsBindingApi()
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiEnabled = false;

                //To modify the settings we need to defer browser creation slightly
                browser.CreateBrowser();

                var loadResponse = await browser.WaitForInitialLoadAsync();

                Assert.True(loadResponse.Success);

                var response1 = await browser.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");
                var response2 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");

                Assert.True(response1.Success, response1.Message);
                Assert.True((bool)response1.Result);

                Assert.True(response2.Success, response2.Message);
                Assert.True((bool)response2.Result);
            }
        }

        [Theory]
        [InlineData("notallowed")]
        [InlineData("notallowed", "alsonotallowed")]
        [InlineData("notallowed", "alsonotallowed", "stillnotallowed")]
        public async Task ShouldDisableJsBindingApiForOrigin(params string[] origins)
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiEnabled = true;
                settings.JavascriptBindingApiAllowOrigins = origins;

                //To modify the settings we need to defer browser creation slightly
                browser.CreateBrowser();

                var loadResponse = await browser.WaitForInitialLoadAsync();

                Assert.True(loadResponse.Success);

                var response1 = await browser.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");
                var response2 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");

                Assert.True(response1.Success, response1.Message);
                Assert.True((bool)response1.Result);

                Assert.True(response2.Success, response2.Message);
                Assert.True((bool)response2.Result);
            }
        }

        [Fact]
        public async Task ShouldEnableJsBindingApiWhenOriginsListIsEmpty()
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiEnabled = true;
                settings.JavascriptBindingApiAllowOrigins = new string[0];

                //To modify the settings we need to defer browser creation slightly
                browser.CreateBrowser();

                var loadResponse = await browser.WaitForInitialLoadAsync();

                Assert.True(loadResponse.Success);

                var response1 = await browser.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");
                var response2 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");

                Assert.True(response1.Success, response1.Message);
                Assert.False((bool)response1.Result);

                Assert.True(response2.Success, response2.Message);
                Assert.False((bool)response2.Result);
            }
        }

        [Theory]
        [InlineData(CefExample.BaseUrl)]
        [InlineData(CefExample.BaseUrl + "/")]
        public async Task ShouldEnableJsBindingApiForOriginWithOrWithoutTrailingSlash(string configuredOrigin)
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiEnabled = true;
                settings.JavascriptBindingApiAllowOrigins = new string[] { configuredOrigin };

                //To modify the settings we need to defer browser creation slightly
                browser.CreateBrowser();

                var loadResponse = await browser.WaitForInitialLoadAsync();

                Assert.True(loadResponse.Success);

                var response1 = await browser.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");
                var response2 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");

                Assert.True(response1.Success, response1.Message);
                Assert.False((bool)response1.Result);

                Assert.True(response2.Success, response2.Message);
                Assert.False((bool)response2.Result);
            }
        }

        [Theory]
        [InlineData(CefExample.BaseUrl + "/")]
        [InlineData("someorigin", CefExample.BaseUrl + "/")]
        [InlineData(CefExample.BaseUrl + "/", "someorigin")]
        [InlineData("firstorigin", "secondorigin", CefExample.BaseUrl + "/")]
        [InlineData("firstorigin", CefExample.BaseUrl + "/", "secondorigin")]
        public async Task ShouldEnableJsBindingApiForOrigin(params string[] origins)
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiEnabled = true;
                settings.JavascriptBindingApiAllowOrigins = origins;

                //To modify the settings we need to defer browser creation slightly
                browser.CreateBrowser();

                var loadResponse = await browser.WaitForInitialLoadAsync();

                Assert.True(loadResponse.Success);

                var response1 = await browser.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");
                var response2 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");

                Assert.True(response1.Success, response1.Message);
                Assert.False((bool)response1.Result);

                Assert.True(response2.Success, response2.Message);
                Assert.False((bool)response2.Result);
            }
        }

        [Fact]
        public async Task ShouldEnableJsBindingApi()
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiEnabled = true;

                //To modify the settings we need to defer browser creation slightly
                browser.CreateBrowser();

                var loadResponse = await browser.WaitForInitialLoadAsync();

                Assert.True(loadResponse.Success);

                var response1 = await browser.EvaluateScriptAsync("typeof window.cefSharp === 'undefined'");
                var response2 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");

                Assert.True(response1.Success, response1.Message);
                Assert.False((bool)response1.Result);

                Assert.True(response2.Success, response2.Message);
                Assert.False((bool)response2.Result);
            }
        }

        [Theory]
        [InlineData("CefSharp.RenderProcessId")]
        [InlineData("cefSharp.renderProcessId")]
        public async Task ShouldReturnRenderProcessId(string script)
        {
            AssertInitialLoadComplete();

            var result = await Browser.EvaluateScriptAsync(script);

            Assert.True(result.Success, result.Message);

            using var process = Process.GetProcessById(Assert.IsType<int>(result.Result));

            Assert.Equal("CefSharp.BrowserSubprocess", process.ProcessName);
        }

        [Fact]
        public async Task ShouldWorkAfterACrossOriginNavigation()
        {
            const string script = @"
                (async function()
                {
                    await CefSharp.BindObjectAsync('bound');
                    return await bound.echo('test');
                })();";

            var boundObj = new BindingTestObject();

#if NETCOREAPP
            Browser.JavascriptObjectRepository.Register("bound", boundObj);
#else
            Browser.JavascriptObjectRepository.Register("bound", boundObj, true);
#endif

            await Browser.LoadUrlAsync("https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/url");
            await Browser.EvaluateScriptAsync<string>(script);
            await Browser.LoadUrlAsync("https://www.google.com");
            await Browser.EvaluateScriptAsync<string>(script);

            Assert.Equal(2, boundObj.EchoMethodCallCount);
        }

        [Fact]
        public async Task ShouldFireResolveObject()
        {
            AssertInitialLoadComplete();

            var objRepository = Browser.JavascriptObjectRepository;

            var evt = await Assert.RaisesAsync<JavascriptBindingEventArgs>(
                a => objRepository.ResolveObject += a,
                a => objRepository.ResolveObject -= a,
                () => Browser.EvaluateScriptAsync("(async function() { await CefSharp.BindObjectAsync('first'); })();"));

            Assert.NotNull(evt);
            Assert.Equal("first", evt.Arguments.ObjectName);
            Assert.Equal("https://cefsharp.example/HelloWorld.html", evt.Arguments.Url);
        }

        [Fact]
        public async Task ShouldFireResolveObjectForUnregisteredObject()
        {
            AssertInitialLoadComplete();

            var objRepository = Browser.JavascriptObjectRepository;

            var boundObj = new BindingTestObject();

#if NETCOREAPP
            objRepository.Register("first", boundObj);
#else
            objRepository.Register("first", boundObj, true);
#endif

            var evt = await Assert.RaisesAsync<JavascriptBindingEventArgs>(
                a => objRepository.ResolveObject += a,
                a => objRepository.ResolveObject -= a,
                () => Browser.EvaluateScriptAsync("(async function() { await CefSharp.BindObjectAsync('first', 'second'); })();"));

            Assert.NotNull(evt);
            Assert.Equal("second", evt.Arguments.ObjectName);
        }

        [Fact]
        public async Task ShouldDisableJsBindingApiAfterCrossOriginNavigationToDisallowedOrigin()
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiEnabled = true;
                settings.JavascriptBindingApiAllowOrigins = new string[] { CefExample.BaseUrl };

                browser.CreateBrowser();

                var loadResponse = await browser.WaitForInitialLoadAsync();

                Assert.True(loadResponse.Success);

                // Binding API should be present on the allowed origin
                var response1 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");
                Assert.True(response1.Success, response1.Message);
                Assert.False((bool)response1.Result);

                // Navigate to a different origin that is not in the allow list
                var crossOriginLoad = await browser.LoadUrlAsync("https://www.google.com");
                Assert.True(crossOriginLoad.Success);

                // Binding API should no longer be present on the disallowed origin
                var response2 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");
                Assert.True(response2.Success, response2.Message);
                Assert.True((bool)response2.Result);
            }
        }

        [Fact]
        public async Task ShouldKeepJsBindingApiEnabledAfterCrossOriginNavigationToAllowedOrigin()
        {
            using (var browser = new ChromiumWebBrowser(CefExample.BindingApiCustomObjectNameTestUrl, automaticallyCreateBrowser: false))
            {
                var settings = browser.JavascriptObjectRepository.Settings;
                settings.JavascriptBindingApiEnabled = true;
                settings.JavascriptBindingApiAllowOrigins = new string[] { CefExample.BaseUrl, "https://www.google.com" };

                browser.CreateBrowser();

                var loadResponse = await browser.WaitForInitialLoadAsync();

                Assert.True(loadResponse.Success);

                // Binding API should be present on the first allowed origin
                var response1 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");
                Assert.True(response1.Success, response1.Message);
                Assert.False((bool)response1.Result);

                // Navigate to a second origin that is also in the allow list
                var crossOriginLoad = await browser.LoadUrlAsync("https://www.google.com");
                Assert.True(crossOriginLoad.Success);

                // Binding API should still be present on the second allowed origin
                var response2 = await browser.EvaluateScriptAsync("typeof window.CefSharp === 'undefined'");
                Assert.True(response2.Success, response2.Message);
                Assert.False((bool)response2.Result);
            }
        }
    }
}
